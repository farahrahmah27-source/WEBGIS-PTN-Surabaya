ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:32749").setExtent([682747.560329, 9187656.528720, 699581.639365, 9198357.077872]);
var wms_layers = [];


        var lyr_Positronnolabels_0 = new ol.layer.Tile({
            'title': 'Positron [no labels]',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://cartodb.com/basemaps/">Map tiles by CartoDB, under CC BY 4.0. Data by OpenStreetMap, under ODbL.</a>',
                url: 'https://a.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png'
            })
        });
var format_AksesibilitasPTN_SBY_1 = new ol.format.GeoJSON();
var features_AksesibilitasPTN_SBY_1 = format_AksesibilitasPTN_SBY_1.readFeatures(json_AksesibilitasPTN_SBY_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:32749'});
var jsonSource_AksesibilitasPTN_SBY_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_AksesibilitasPTN_SBY_1.addFeatures(features_AksesibilitasPTN_SBY_1);
var lyr_AksesibilitasPTN_SBY_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_AksesibilitasPTN_SBY_1, 
                style: style_AksesibilitasPTN_SBY_1,
                popuplayertitle: 'Aksesibilitas PTN_SBY',
                interactive: true,
                title: '<img src="styles/legend/AksesibilitasPTN_SBY_1.png" /> Aksesibilitas PTN_SBY'
            });
var format_PTN_SBY_2 = new ol.format.GeoJSON();
var features_PTN_SBY_2 = format_PTN_SBY_2.readFeatures(json_PTN_SBY_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:32749'});
var jsonSource_PTN_SBY_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_PTN_SBY_2.addFeatures(features_PTN_SBY_2);
var lyr_PTN_SBY_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_PTN_SBY_2, 
                style: style_PTN_SBY_2,
                popuplayertitle: 'PTN_SBY',
                interactive: true,
    title: 'PTN_SBY<br />\
    <img src="styles/legend/PTN_SBY_2_0.png" /> ITS<br />\
    <img src="styles/legend/PTN_SBY_2_1.png" /> UIN Sunan Ampel<br />\
    <img src="styles/legend/PTN_SBY_2_2.png" /> UNAIR<br />\
    <img src="styles/legend/PTN_SBY_2_3.png" /> UNESA<br />\
    <img src="styles/legend/PTN_SBY_2_4.png" /> UPNV Jatim<br />' });

lyr_Positronnolabels_0.setVisible(true);lyr_AksesibilitasPTN_SBY_1.setVisible(true);lyr_PTN_SBY_2.setVisible(true);
var layersList = [lyr_Positronnolabels_0,lyr_AksesibilitasPTN_SBY_1,lyr_PTN_SBY_2];
lyr_AksesibilitasPTN_SBY_1.set('fieldAliases', {'fid': 'fid', 'Access': 'Access', });
lyr_PTN_SBY_2.set('fieldAliases', {'fid': 'fid', 'Nama': 'Nama', 'Kampus': 'Kampus', 'Foto': 'Foto', 'Deskripsi Univ_QS WUR': 'Deskripsi Univ_QS WUR', 'Deskripsi Univ_Didirikan': 'Deskripsi Univ_Didirikan', 'Deskripsi Univ_Fakultas': 'Deskripsi Univ_Fakultas', });
lyr_AksesibilitasPTN_SBY_1.set('fieldImages', {'fid': 'TextEdit', 'Access': 'TextEdit', });
lyr_PTN_SBY_2.set('fieldImages', {'fid': 'TextEdit', 'Nama': 'TextEdit', 'Kampus': 'TextEdit', 'Foto': 'ExternalResource', 'Deskripsi Univ_QS WUR': 'TextEdit', 'Deskripsi Univ_Didirikan': 'TextEdit', 'Deskripsi Univ_Fakultas': 'TextEdit', });
lyr_AksesibilitasPTN_SBY_1.set('fieldLabels', {'fid': 'no label', 'Access': 'inline label - visible with data', });
lyr_PTN_SBY_2.set('fieldLabels', {'fid': 'hidden field', 'Nama': 'inline label - always visible', 'Kampus': 'inline label - always visible', 'Foto': 'inline label - always visible', 'Deskripsi Univ_QS WUR': 'inline label - always visible', 'Deskripsi Univ_Didirikan': 'inline label - always visible', 'Deskripsi Univ_Fakultas': 'inline label - always visible', });
lyr_PTN_SBY_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});